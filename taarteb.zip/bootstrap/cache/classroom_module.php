<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Classroom\\App\\Providers\\ClassroomServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Classroom\\App\\Providers\\ClassroomServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);