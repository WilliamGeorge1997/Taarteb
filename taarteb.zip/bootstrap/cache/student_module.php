<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Student\\App\\Providers\\StudentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Student\\App\\Providers\\StudentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);