<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Session\\App\\Providers\\SessionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Session\\App\\Providers\\SessionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);