<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Common\\App\\Providers\\CommonServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Common\\App\\Providers\\CommonServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);