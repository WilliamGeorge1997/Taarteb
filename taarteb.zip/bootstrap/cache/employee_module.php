<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Employee\\App\\Providers\\EmployeeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Employee\\App\\Providers\\EmployeeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);