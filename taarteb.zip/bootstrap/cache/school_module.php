<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\School\\App\\Providers\\SchoolServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\School\\App\\Providers\\SchoolServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);