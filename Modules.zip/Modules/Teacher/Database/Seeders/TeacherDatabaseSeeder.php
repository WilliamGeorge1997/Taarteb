<?php

namespace Modules\Teacher\Database\Seeders;

use Illuminate\Database\Seeder;

class TeacherDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
