<?php

namespace Modules\Employee\Database\Seeders;

use Illuminate\Database\Seeder;

class EmployeeDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
