<?php

return [
    'name' => 'Class',
];
