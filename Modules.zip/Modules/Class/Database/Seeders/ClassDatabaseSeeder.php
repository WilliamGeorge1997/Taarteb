<?php

namespace Modules\Class\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\Class\App\Models\Classroom;

class ClassDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
    }
}
