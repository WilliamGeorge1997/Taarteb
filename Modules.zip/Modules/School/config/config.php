<?php

return [
    'name' => 'School',
];
