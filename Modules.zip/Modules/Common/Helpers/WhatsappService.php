<?php

namespace Modules\Common\Helpers;

use Netflie\WhatsAppCloudApi\WhatsAppCloudApi;


class WhatsappService
{
    private $whatsapp;

    public function __construct()
    {
        $WHATSAPP_FROM_PHONE_NUMBER_ID='555865087618583';
        $WHATSAPP_TOKEN='EAAbt67njH2wBO71QoQthGt4vwPV1ClhoJ4jAzKtnqxQ43lbzkHOWzjl6SNdibCi8wNGWTXdppOCSYGYsjloVda6D77eAsZACpVh9nco2KVT0lr7PQqGF4AUUa8gQZBxq3JgSso95aO0Mb1ZBjbDutCdhyyW6qJtZCjbl8wiF1sNNHZCYKYkUtbqqAO0amolmcxkllK9f8bcGN6rneIwCW29qXQ3ryS29ma8fZC44hoqanN';
        $this->whatsapp = new WhatsAppCloudApi([
            'from_phone_number_id' => $WHATSAPP_FROM_PHONE_NUMBER_ID,
            'access_token' => $WHATSAPP_TOKEN,
        ]);
    }

     function sendTextMessage(string $to, string $message)
    {
        return $this->whatsapp->sendTextMessage($to, $message);
    }

    public function sendTemplate(string $to, string $templateName, string $languageCode = 'en_US', array $components = [])
    {
        // Convert array to Component objects if needed
        $componentObjects = empty($components) ? null : $components;

        return $this->whatsapp->sendTemplate(
            $to,
            $templateName,
            $languageCode,
            $componentObjects
        );
    }
}