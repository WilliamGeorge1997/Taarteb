<?php

namespace Modules\Expense\Database\Seeders;

use Illuminate\Database\Seeder;

class ExpenseDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
