<?php

return [
    'name' => 'Purchase',
];
