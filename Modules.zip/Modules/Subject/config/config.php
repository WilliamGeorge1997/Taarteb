<?php

return [
    'name' => 'Subject',
];
