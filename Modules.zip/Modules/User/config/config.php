<?php

return [
    'name' => 'User',
];
