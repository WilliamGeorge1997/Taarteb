<?php

namespace Modules\Session\Database\Seeders;

use Illuminate\Database\Seeder;

class SessionDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
